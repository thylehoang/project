import java.util.ArrayList;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Input;

public class Builder extends Unit{
	private static final String BUILDER_PATH = "assets/units/builder.png";
	private static final String name = "builder";
	private static final double SPEED = 0.1;
	private Image icon;
	private double time;
	private double pressed_time;
	private boolean allow = true;
	private int hold_metal;

	//constructor
	public Builder(double x, double y) throws SlickException {
		super(x, y);
		icon = new Image(BUILDER_PATH);
	}

	@Override
	//get icon of builder
	public Image getIcon() {
		return icon;
	}

	@Override
	//get builder name
	public String getName() {
		return name;
	}
	

	@Override
	/**
	 * to handle creation ability of factory
	 * @param world 
	 * @param array of units
	 * @param array of building
	 * 
	 * @return handle creation of object
	 */
	public void doWork(World world,ArrayList<Building> buildings, ArrayList<Unit> units) throws SlickException{
		Input input = world.getInput();
		hold_metal = world.getHoldMetal();
		time+=world.getDelta();
		if(input.isKeyPressed(Input.KEY_1) && hold_metal >=100) {
			//check if there is enough resource
			pressed_time = time;
			allow = false;
		}
		if(time-pressed_time>= 10000) {
				buildings.add(Building.createBuilding("factory",getX(), getY()));
				allow = true;
				world.setHoldMetal(0, 100);
				time = 0;
				pressed_time = 0;
		}
	}

	@Override
	//return speed of builder
	public double getSpeed() {
		// TODO Auto-generated method stub
		return SPEED;
	}

	@Override
	/**
	 * get text show option of creation
	 * @param graphics 
	 */
	public void drawText(Graphics g) {
		g.drawString("1- Create Factory\n",32,100);
	}

	@Override
	//return true if allow to move
	public boolean getAllow() {
		// TODO Auto-generated method stub
		return allow;
	}
}
