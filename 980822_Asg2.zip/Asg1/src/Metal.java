import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

public class Metal extends Resource{
	private int hold;
	//constructor of metal
	public Metal(double x, double y) throws SlickException {
		super(x, y);
		hold = 150;
		icon = new Image(METAL_PATH);
		
		// TODO Auto-generated constructor stub
	}

	private static final String METAL_PATH = "assets/resources/metal_mine.png";
	private static final String name = "metal_mine";
	private Image icon;
	
	//get image of the resource
	@Override
	public Image getIcon() {
		// TODO Auto-generated method stub
		return icon;
	}
	
	//get the resource name
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	
	//get the holding resource from this resource
	@Override
	public int getHold() {
		// TODO Auto-generated method stub
		return 0;
	}
}