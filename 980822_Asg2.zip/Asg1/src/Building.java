import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import java.util.ArrayList;

/**
 *this class got updated from the solution of asignment 1 (if any)
 */
public abstract class Building {
	private double x;
	private double y;
	
	//get position of x
	public double getX() {
		return x;
	}
	
	//get position of y
	public double getY() {
		return y;
	}
	
	//set position of x
	public void setX(double x) {
		this.x = x;
	}
	
	//set position of y
	public void setY(double y) {
		this.y = y;
	}
	
	
	/**
	 * constructor of building
	 * @param position x
	 * @param position y
	 */
	public Building(double x, double y)  throws SlickException{
		this.x = x;
		this.y = y;
	}
	
	/**
	 * help to create building when needed
	 * @param name of building 
	 * @param position x
	 * @param position y
	 * 
	 * @return building at position x and position y
	 */
	public static Building createBuilding(String name, double x, double y) throws SlickException{
		switch(name) {
		case "factory":
			return new Factory(x, y);
		case "pylon":
			return new Pylon(x, y);
		case "command_centre":
			return new Command_center(x,y);
		}
		return null;
	}
	
	/**
	 * get image of command center
	 * @return image of building 
	 */
	public abstract Image getIcon();
	
	/**
	 * get building name
	 * @return name of building
	 */
	public abstract String getName();
	
	/**
	 * get text show option for creation for each type of building
	 * @param graphics 
	 */
	public abstract void drawText(Graphics g);
	
	public void update(World world, ArrayList<Building> buildings, ArrayList<Unit> units) throws SlickException {
		doWork(world, buildings, units);
	}
	
	/**
	 * to handle creation suitable for each building
	 * @param world 
	 * @param array of units
	 * @param array of building
	 * 
	 * @return handle creation of object
	 */
	public abstract void doWork(World world, ArrayList<Building> buildings, ArrayList<Unit> units)throws SlickException;
	
	/**
	 * help to render building on map by their icon
	 * @param world
	 */
	public void render(World world) {
		Camera camera = world.getCamera();
		getIcon().drawCentered((int)camera.globalXToScreenX(getX()),
   				(int)camera.globalYToScreenY(getY()));
	}

}
