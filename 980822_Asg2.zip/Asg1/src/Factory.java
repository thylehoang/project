import org.newdawn.slick.Input;

import java.util.ArrayList;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

public class Factory extends Building {
	
	private static final String FACTORY_PATH = "assets/buildings/factory.png";
	private String name = "factory";
	private Image icon;
	private double time;
	private double pressed_time;
	private int hold_metal;
	//constructor 
	public Factory(double x, double y) throws SlickException {
		super(x,y);
		icon= new Image(FACTORY_PATH);
	}
	
	//get name of factory
	public String getName() {
		return name;
	}
	
	//getter and setter for icon for this class
	public Image getIcon() {
		return icon;
	}
	
	/**
	 * to handle creation of command center
	 * @param world 
	 * @param array of units
	 * @param array of building
	 * 
	 * @return handle creation of object
	 */
	@Override
	public void doWork(World world, ArrayList<Building> buildings, ArrayList<Unit> units) throws SlickException {
		// TODO Auto-generated method stub
		Input input = world.getInput();
		hold_metal = world.getHoldMetal();
		
		time += world.getDelta();
		if(input.isKeyPressed(Input.KEY_1) && hold_metal >=150) {
			//check if there is enough resource
			pressed_time = time;
		}
		
		if(time-pressed_time>= 5000) {
			units.add(Unit.createUnit("truck",getX(), getY()));
			world.setHoldMetal(0, 20);
			time = 0;
			pressed_time = 0;
		}
	}

	@Override
	/**
	 * get text show option of creation
	 * @param graphics 
	 */
	public void drawText(Graphics g) {
		g.drawString("1- Create Truck\n",32,100);
	}
}
