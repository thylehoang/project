import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

public class Unob extends Resource{
	private int hold;
	
	//constructor of metal
	public Unob (double x, double y) throws SlickException {
		super(x, y);
		icon = new Image(UNOB_PATH);
		hold = 50;
		// TODO Auto-generated constructor stub
	}
	
	private static final String UNOB_PATH = "assets/resources/unobtainium_mine.png";
	private static final String name = "unobtainium_mine";
	private Image icon;
	
	//get image of the resource
	@Override
	public Image getIcon() {
		// TODO Auto-generated method stub
		return icon;
	}
	
	//get the resource name
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	
	//get the holding resource from this resource
	@Override
	public int getHold() {
		// TODO Auto-generated method stub
		return hold;
	}
	
}
