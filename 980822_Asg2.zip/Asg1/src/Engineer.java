import java.util.ArrayList;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

public class Engineer extends Unit{
	private static final String name = "Engineer";
	private static final String ENGINEER_PATH = "assets/units/engineer.png";
	private Image icon;
	private static final double SPEED = 0.1;
	public Engineer(double x, double y) throws SlickException {
		super(x, y);
		icon = new Image(ENGINEER_PATH);
	}
	@Override
	public Image getIcon() {
		return icon;
	}
	@Override
	public String getName() {
		return name;
	}
	
	@Override
	public double getSpeed() {
		// TODO Auto-generated method stub
		return SPEED;
	}
	@Override
	public void doWork(World world, ArrayList<Building> buildings, ArrayList<Unit> units) throws SlickException {
		// TODO Auto-generated method stub
		return;
	}
	@Override
	public void drawText(Graphics g) {
		// TODO Auto-generated method stub
		return;
	}
	@Override
	public boolean getAllow() {
		// TODO Auto-generated method stub
		return true;
	}

}
