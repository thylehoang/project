import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.tiled.TiledMap;
import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.String;
import java.lang.Double;
import java.util.ArrayList;

/**
 * This class should be used to contain all the different objects in your game world, and schedule their interactions.
 * 
 * You are free to make ANY modifications you see fit.
 * These classes are provided simply as a starting point. You are not strictly required to use them.
 */

/**
 *this class got updated from the solution of asignment 1
 */
 
public class World {
	private static final String MAP_PATH = "assets/main.tmx";
	private static final String HIGHLIGHT_PATH_LARGE = "assets/highlight_large.png";
	private static final String HIGHLIGHT_PATH = "assets/highlight.png";
	private static final String SOLID_PROPERTY = "solid";
	private static final String FILENAME = "assets/objects.csv";
	private static final int RANGE = 32;
	private double targetX;
	private double targetY;
	private static final int TEXT_COOR_X = 32;
	private static final int TEXT_COOR_Y = 32;
	private int hold_metal = 0;
	private int hold_uno = 0;
	private Image highlight;
	private Image highlight_large;

	                                                                 
	private TiledMap map;
	private Camera camera;
	
	//get camera
	public Camera getCamera() {
		return camera;
	}
	private Input lastInput;
	private int lastDelta;
	
	//get input
	public Input getInput() {
		return lastInput;
	}
	
	//gt delta
	public int getDelta() {
		return lastDelta;
	}
	
	//get number of available metal
	public int getHoldMetal() {
		return hold_metal;
	}
	
	//reset the number of metal holding
	public void setHoldMetal(int add, int minus) {
		this.hold_metal = this.hold_metal+add-minus;
	}
	
	//check position on map
	public boolean isPositionFree(double x, double y) {
		int tileId = map.getTileId(worldXToTileX(x), worldYToTileY(y), 0);
		return !Boolean.parseBoolean(map.getTileProperty(tileId, SOLID_PROPERTY, "false"));
	}
	
	//get map width
	public double getMapWidth() {
		return map.getWidth() * map.getTileWidth();
	}
	
	//get map height
	public double getMapHeight() {
		return map.getHeight() * map.getTileHeight();
	}
	
	//array list to store variable in game
	private ArrayList<Building> buildings = new ArrayList<Building>();
	private ArrayList<Unit> units = new ArrayList<Unit>();
	private ArrayList<Resource> resources = new ArrayList<Resource>();
	
	/**
	 * creation of world, including given resource, building and units
	 */
	public World() throws SlickException {
		map = new TiledMap(MAP_PATH);
		//sprite = new Sprite(camera);
		camera= new Camera();
		highlight = new Image(HIGHLIGHT_PATH);
		highlight_large = new Image(HIGHLIGHT_PATH_LARGE);
		
		//reading csv file
		try (BufferedReader reader = new BufferedReader(new FileReader(FILENAME))) {
			String text;
			
			while ((text = reader.readLine()) != null) {
				String line[] = text.split(",");
				//System.out.printf("%s", line[0]);
				if(line[0].equals("pylon") || line[0].equals("command_centre") || line[0].equals("factory")) {
					buildings.add(Building.createBuilding(line[0], Double.parseDouble(line[1]), Double.parseDouble(line[2])));
				}else if(line[0].equals("engineer") || line[0].equals("builder") || line[0].equals("scout") || line[0].equals("scout")) {
					units.add(Unit.createUnit(line[0], Double.parseDouble(line[1]), Double.parseDouble(line[2])));
				}else if(line[0].equals("metal_mine") || line[0].equals("unobtainium_mine"))
					resources.add(Resource.createResource(line[0], Double.parseDouble(line[1]), Double.parseDouble(line[2])));
			};
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//selected unit and building
	private Building selectB = null;
	private Unit selectU = null;
	
	/**
	 * update the whole world
	 * @param input
	 * @param delta
	 */
	//world update handle selection and camera
	public void update(Input input, int delta) throws SlickException {
		lastInput = input;
		lastDelta = delta;
		
		//to select and deselect
		if (input.isMousePressed(Input.MOUSE_LEFT_BUTTON)) {
			targetX = camera.screenXToGlobalX(input.getMouseX());
			targetY = camera.screenYToGlobalY(input.getMouseY());
			//deselect everything
			if(selectU != null && selectB == null) {
				selectU = null;
			}else {
				selectB = null;
			}
			//select any building in range
			for(Building b: buildings) {
				if (World.distance(b.getX(), b.getY(), targetX, targetY) <= RANGE) {
					selectB = b;
				}
			}
			//select any unit in range
			for(Unit u: units) {
				if(World.distance(u.getX(),u.getY(), targetX, targetY) <= RANGE) {
					selectU = u;
				}
			}
			//select unit before building if it both close
			if(selectU!=null && selectB != null) {
				selectB=null;
			}
		}
		//if follow is unit
		if(selectU != null) {
			selectU.update(this, buildings, units);
			camera.followObject(selectU);
		}
			
		//if follow is building
		if(selectB != null) {
			selectB.update(this, buildings, units);
			camera.followObject(selectB);
		}
		//update camera
		camera.update(this);
	}
	
	/**
	 * render of world
	 * @param graphics 
	 */
	public void render(Graphics g) {
		map.render((int)camera.globalXToScreenX(0),
				   (int)camera.globalYToScreenY(0));
		g.drawString("Metal: "+hold_metal+"\nUnobtainium: "+hold_uno,32, 32);
		if(selectU!=null) {
			highlight.drawCentered((int)camera.globalXToScreenX(selectU.getX()),
	   				(int)camera.globalYToScreenY(selectU.getY()));
			selectU.drawText(g);
		}
		if(selectB!=null) {
			highlight_large.drawCentered((int)camera.globalXToScreenX(selectB.getX()),
	   				(int)camera.globalYToScreenY(selectB.getY()));
			selectB.drawText(g);
		}
		
		for(Building b :buildings) {
			b.render(this);
		}
		for(Unit u: units) {
			u.render(this);
		}
		for(Resource r: resources) {
			r.render(this);
		}
	}
	
	// This should probably be in a separate static utilities class, but it's a bit excessive for one method.
	public static double distance(double x1, double y1, double x2, double y2) {
		return (double)Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
	}
	
	private int worldXToTileX(double x) {
		return (int)(x / map.getTileWidth());
	}
	private int worldYToTileY(double y) {
		return (int)(y / map.getTileHeight());
	}
}
