import java.util.ArrayList;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

public class Truck extends Unit{
	private static final String TRUCK_PATH = "assets/units/truck.png";
	private static final String name = "truck";
	private static final double SPEED = 0.25;
	private Image icon;
	private double time;
	private double pressed_time;
	private boolean allow = true;
	private int hold_metal;
	
	//construction of truck
	public Truck(double x, double y) throws SlickException {
		super(x, y);
		icon = new Image(TRUCK_PATH);
	}

	@Override
	//get truck icon
	public Image getIcon() {
		// TODO Auto-generated method stub
		return icon;
	}

	@Override
	//get truck name
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	/**
	 * to handle creation ability of truck -which is command center
	 * @param world 
	 * @param array of units
	 * @param array of building
	 * 
	 * @return handle creation of object
	 */
	public void doWork(World world, ArrayList<Building> buildings, ArrayList<Unit> units) throws SlickException {
		// TODO Auto-generated method stub
		Input input = world.getInput();
		hold_metal = world.getHoldMetal();
		time+=world.getDelta();
		if(input.isKeyPressed(Input.KEY_1) && hold_metal >=100) {
			pressed_time = time;
			allow = false;
		}
		//if time is 15 seconds
		if(time-pressed_time>= 15000) {
			buildings.add(Building.createBuilding("command_centre",getX(), getY()));
			allow = true;
			world.setHoldMetal(0, 100);
			time = 0;
			pressed_time =0;
			units.remove(this);
		}
	}

	@Override
	//get truck speed
	public double getSpeed() {
		// TODO Auto-generated method stub
		return SPEED;
	}

	@Override
	/**
	 * get text show option of creation
	 * @param graphics 
	 */
	public void drawText(Graphics g) {
		g.drawString("1- Create Command Center\n",32,100);
	}

	@Override
	//return true if the truck able to move at certain time
	public boolean getAllow() {
		// TODO Auto-generated method stub
		return allow;
	}

}

