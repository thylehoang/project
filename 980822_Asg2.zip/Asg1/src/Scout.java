import java.util.ArrayList;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Input;

public class Scout extends Unit{
	private static final String name = "scout";
	private static final String SCOUT_PATH = "assets/units/scout.png";
	private static final double SPEED =  0.3;
	private static final int RANGE = 32;
	private double targetX;
	private double targetY;
	private double x;
	private double y;
	private Image icon;
	
	//construction of scout
	public Scout(double x, double y) throws SlickException {
		super(x, y);
		icon = new Image(SCOUT_PATH);
	}
	
	@Override
	//get image of scout
	public Image getIcon() {
		return icon;
	}
	
	@Override
	//get name scout
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	
	/**
	 * to handle creation of units-which here is none
	 * @param world 
	 * @param array of units
	 * @param array of building
	 * 
	 * @return handle creation of object
	 */
	public void doWork(World world, ArrayList<Building> buildings, ArrayList<Unit> units)throws SlickException{
	}
	
	@Override
	//get speed of scout
	public double getSpeed() {
		// TODO Auto-generated method stub
		return SPEED;
	}
	
	@Override
	//to draw any text from scout information
	public void drawText(Graphics g) {
		// TODO Auto-generated method stub
		return;
	}
	
	@Override
	//return true if scout able to move
	public boolean getAllow() {
		// TODO Auto-generated method stub
		return true;
	}
}
