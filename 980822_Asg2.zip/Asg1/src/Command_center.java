import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

import java.util.ArrayList;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;

public class Command_center extends Building{

	private static final String CC_PATH = "assets/buildings/command_centre.png";
	private String name = "command_center";
	private int key;
	private Image icon = new Image(CC_PATH);
	private double time;
	private double pressed_time;
	private boolean allow;
	private int hold_metal;
	
	/**
	 * constructor of command center
	 * @param position x
	 * @param position y
	 */
	public Command_center(double x, double y) throws SlickException{
		super(x, y);
	}
	
	/**
	 * get command center name
	 * @return command center as string
	 */
	public String getName() {
		return name;
	}
	
	
	/**
	 * get image of command center
	 * @return image of command center
	 */
	public Image getIcon() {
		return icon;
	}

	/**
	 * to handle creation of command center
	 * @param world 
	 * @param array of units
	 * @param array of building
	 * 
	 * @return handle creation of object
	 */
	@Override
	public void doWork(World world, ArrayList<Building> buildings, ArrayList<Unit> units) throws SlickException {
		// TODO Auto-generated method stub
		Input input = world.getInput();
		hold_metal = world.getHoldMetal();
		time += world.getDelta();
		// to calculate time
		if(input.isKeyPressed(Input.KEY_1) && hold_metal >=5) {
			//check if there is enough resource
			key = 1;
			pressed_time = time;
			allow = false;
		}
		if(input.isKeyPressed(Input.KEY_2) && hold_metal >=10) {
			//check if there is enough resource
			key = 2;
			pressed_time = time;
			allow = false;
		}
		if(input.isKeyPressed(Input.KEY_3) && hold_metal >=20) {
			//check if there is enough resource
			pressed_time = time;
			key = 3;
			allow = false;
		}
		//if time had passed 5 seconds
		if(time-pressed_time>= 5000) {
			//create scout
			if(key == 1) {
				units.add(Unit.createUnit("scout",getX(), getY()));
				world.setHoldMetal(0, 5);
				key=0;
			//create builder
			}else if(key==2) {
				units.add(Unit.createUnit("builder",getX(), getY()));
				world.setHoldMetal(0, 10);
				key=0;
			//create engineer
			}else if(key == 3) {
				units.add(Unit.createUnit("engineer",getX(), getY()));
				world.setHoldMetal(0, 20);
				key=0;
			}
			allow = true;
			time = 0;
			pressed_time = 0;
		}
	}
	
	/**
	 * get text show option of creation
	 * @param graphics 
	 */
	@Override
	public void drawText(Graphics g) {
		g.drawString("1- Create scout\n2- Create Builder\n3- Create Engineer\n",32,100);
	}
}