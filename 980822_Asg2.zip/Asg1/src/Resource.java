import java.util.ArrayList;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

/**
 *this class got updated from the solution of asignment 1
 */
public abstract class Resource {
	private double x;
	private double y;
	
	//get position of x
	public double getX() {
		return x;
	}
	
	//get position of x
	public double getY() {
		return y;
	}
	
	//set position of x
	public void setX(double x) {
		this.x = x;
	}
	
	//set position of y
	public void setY(double y) {
		this.y = y;
	}
	
	/**
	 * resource constructor
	 * @param position x
	 * @param position 
	 */
	public Resource(double x, double y)  throws SlickException{
		this.x = x;
		this.y = y;
	}
	
	/**
	 * help to create resource when needed
	 * @param name of resource 
	 * @param position x
	 * @param position y
	 * 
	 * @return resource at position x and position y
	 */
	public static Resource createResource(String name, double x, double y) throws SlickException{
		switch(name) {
		case "metal_mine":
			return new Metal(x, y);
		case "unobtainium_mine":
			return new Unob(x,y);
		}
		return null;
	}
	
	/**
	 * help to create resource when needed
	 * @param array of resource
	 */
	public void update(ArrayList<Resource> resources) {
		for(Resource r: resources) {
			if(getHold()<=0) {
				resources.remove(r);
			}
		}
	}
	
	/**
	 * get image belong to the resource type
	 * @param graphics
	 * @return icon as image 
	 */
	public abstract Image getIcon();
	
	/**
	 * get unit name
	 * @return name of resource as a string
	 */
	public abstract String getName();
	
	/**
	 * get holding resource 
	 * @return number of resource left as an interger
	 */
	public abstract int getHold();
	
	/**
	 * help to render resource on map by their icon
	 * @param world
	 */
	public void render(World world) {
		Camera camera = world.getCamera();
		getIcon().drawCentered((int)camera.globalXToScreenX(getX()),
   				(int)camera.globalYToScreenY(getY()));
	}
}
