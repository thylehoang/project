import org.newdawn.slick.Input;
import java.util.ArrayList;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Input;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

public class Pylon extends Building {
	
	private static final String PYLON_NOTACTIVE = "assets/buildings/pylon.png";
	private static final String PYLON_ACTIVE = "assets/buildings/pylon_active.png";
	private String name = "pylon";
	private boolean status = true;
	private Image activatedIcon = new Image(PYLON_ACTIVE);
	
	/**
	 * change status to activated
	 */
	public void activated() {
		status = false;
	}
	
	/**
	 * reset image of pylon to activate
	 */
	public void changeImage() {
		icon = activatedIcon;
	}
	private Image icon;
	
	public String getName() {
		return name;
	}
	
	/**
	 * constructor of pylon
	 * @param position x
	 * @param position y
	 */
	public Pylon(double x, double y) throws SlickException {
		super(x,y);
		icon = new Image(PYLON_NOTACTIVE);
	}
	
	/**
	 * get image of pylon
	 * @return image of pylon
	 */
	public Image getIcon() {
		return icon;
	}
	
	// this is for fun =-=
	public void update() throws SlickException {
	}
	
	//this is for any work that specialised of pylon
	@Override
	public void doWork(World world, ArrayList<Building> buildings, ArrayList<Unit> units) throws SlickException {
		// TODO Auto-generated method stub
		return;
	}
	
	//to draw any option of action for pylon, which is none
	@Override
	public void drawText(Graphics g) {
		// TODO Auto-generated method stub
		return;
	}
	
}
