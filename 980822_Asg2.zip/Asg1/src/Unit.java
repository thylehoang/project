import java.util.ArrayList;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

/**
 *this class got updated from the solution of asignment 1
 */
public abstract class Unit{
	private double x;
	private double y;
	private double targetX;
	private double targetY;
	
	//get position of x
	public double getX() {
		return x;
	}
	//get position of y
	public double getY() {
		return y;
	}
	
	//set position of x
	public void setX(double x, double add) {
		this.x = x+add;
	}
	
	//set position of y
	public void setY(double y, double add) {
		this.y = y+add;
	}

	
	/**
	 * unit constructor
	 * @param position x
	 * @param position 
	 */
	public Unit(double x, double y)  throws SlickException{
		this.x = x;
		this.y = y;
	}
	
	/**
	 * help to create unit when needed
	 * @param name of unit 
	 * @param position x
	 * @param position y
	 * 
	 * @return unit at position x and position y
	 */
	public static Unit createUnit(String name, double x, double y) throws SlickException{
		switch(name) {
		case "scout":
			return new Scout(x, y);
		case "engineer":
			return new Engineer(x, y);
		case "truck":
			return new Truck(x, y);
		case "builder":
			return new Builder(x, y);
		}
		return null;
	}
	
	/**
	 * get image belong to the unit type
	 * @param graphics
	 * @return icon as image 
	 */
	public abstract Image getIcon();
	
	/**
	 * get unit name
	 * @return name of unit as a string
	 */
	public abstract String getName();
	
	/**
	 * get unit speed
	 * @return name of unit as double
	 */
	public abstract double getSpeed();
	
	/**
	 * get allow as boolean to indicate whether the object should move
	 * @return true as able move, false as not allow to move
	 */
	public abstract boolean getAllow();
	
	/**
	 * handle moving of units
	 * @param world
	 * @param array of buildings
	 * @param array of units
	 */
	public void update(World world, ArrayList<Building> buildings, ArrayList<Unit> units) throws SlickException {
		
		Input input = world.getInput();
		Camera camera = world.getCamera();
		doWork(world, buildings, units);
		
		// If the mouse button is bing clicked, set the target to the cursor location
		if (input.isMousePressed(Input.MOUSE_RIGHT_BUTTON) && (getAllow() == true)) {
			targetX = camera.screenXToGlobalX(input.getMouseX());
			targetY = camera.screenYToGlobalY(input.getMouseY());
		}
		
		// If we're close to our target, reset to our current position
		if (World.distance(x, y, targetX, targetY) <= getSpeed()) {
			resetTarget();
		} else {
			if((targetX != -1) && (targetY != -1)) {
				double theta = Math.atan2(targetY - y, targetX - x);
				double dx = (double)Math.cos(theta) * world.getDelta() * getSpeed();
				double dy = (double)Math.sin(theta) * world.getDelta() * getSpeed();
				// Check the tile is free before moving; otherwise, we stop moving
				if (world.isPositionFree(x + dx, y + dy)) {
					x += dx;
					y += dy;
				} else {
					resetTarget();
				}
			}
			// Calculate the appropriate x and y distances
		}
		// to activate if any unit move close to pylon
		for(Building building:buildings) {
			if(building instanceof Pylon) {
				if(World.distance(getX(), getY(), building.getX(), building.getY()) <= 32) {
					((Pylon)building).changeImage();
					//pylon set to activated
					((Pylon)building).activated();
				}
			}
		}
	}
	
	/**
	 * to reset the position while moving
	 */
	private void resetTarget() {
		targetX = x;
		targetY = y;		
	}
	
	/**
	 * get image belong to the unit type
	 * @param graphics 
	 */
	public abstract void drawText(Graphics g);
	
	/**
	 * to handle creation suitable for each unit
	 * @param world 
	 * @param array of units
	 * @param array of building
	 * 
	 * @return handle creation of unit
	 */
	public abstract void doWork(World world, ArrayList<Building> buildings, ArrayList<Unit> units)throws SlickException;
	
	/**
	 * help to render unit on map by their icon
	 * @param world
	 */
	public void render(World world) {
		Camera camera = world.getCamera();
		getIcon().drawCentered((int)camera.globalXToScreenX(getX()),
   				(int)camera.globalYToScreenY(getY()));
	}

}
